function retVal=multi_partial(AZ,Omega_linear)
retVal=AZ(Omega_linear);
retVal=retVal';
end